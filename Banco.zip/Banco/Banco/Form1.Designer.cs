﻿
namespace Banco
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_titular = new System.Windows.Forms.Label();
            this.lbl_saldo = new System.Windows.Forms.Label();
            this.lbl_numeroconta = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.lbl_valor = new System.Windows.Forms.Label();
            this.txt_titular = new System.Windows.Forms.TextBox();
            this.txt_numero_conta = new System.Windows.Forms.TextBox();
            this.txt_saldoatual = new System.Windows.Forms.TextBox();
            this.TXT_VALOR = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.rdb_sacar = new System.Windows.Forms.RadioButton();
            this.rdb_depositar = new System.Windows.Forms.RadioButton();
            this.BTN_EXECUTAR = new System.Windows.Forms.Button();
            this.BTN_NOVA_CONTA = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lbl_titular
            // 
            this.lbl_titular.AutoSize = true;
            this.lbl_titular.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_titular.Location = new System.Drawing.Point(34, 58);
            this.lbl_titular.Name = "lbl_titular";
            this.lbl_titular.Size = new System.Drawing.Size(98, 16);
            this.lbl_titular.TabIndex = 0;
            this.lbl_titular.Text = "Nome do titular";
            // 
            // lbl_saldo
            // 
            this.lbl_saldo.AutoSize = true;
            this.lbl_saldo.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_saldo.Location = new System.Drawing.Point(34, 129);
            this.lbl_saldo.Name = "lbl_saldo";
            this.lbl_saldo.Size = new System.Drawing.Size(76, 16);
            this.lbl_saldo.TabIndex = 1;
            this.lbl_saldo.Text = "Saldo atual";
            // 
            // lbl_numeroconta
            // 
            this.lbl_numeroconta.AutoSize = true;
            this.lbl_numeroconta.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_numeroconta.Location = new System.Drawing.Point(34, 93);
            this.lbl_numeroconta.Name = "lbl_numeroconta";
            this.lbl_numeroconta.Size = new System.Drawing.Size(111, 16);
            this.lbl_numeroconta.TabIndex = 2;
            this.lbl_numeroconta.Text = "Numero da conta";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(32, 200);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(100, 18);
            this.label4.TabIndex = 3;
            this.label4.Text = "OPERAÇÃO";
            // 
            // lbl_valor
            // 
            this.lbl_valor.AutoSize = true;
            this.lbl_valor.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_valor.Location = new System.Drawing.Point(33, 250);
            this.lbl_valor.Name = "lbl_valor";
            this.lbl_valor.Size = new System.Drawing.Size(50, 20);
            this.lbl_valor.TabIndex = 4;
            this.lbl_valor.Text = "Valor ";
            // 
            // txt_titular
            // 
            this.txt_titular.Location = new System.Drawing.Point(213, 54);
            this.txt_titular.Name = "txt_titular";
            this.txt_titular.Size = new System.Drawing.Size(219, 20);
            this.txt_titular.TabIndex = 7;
            // 
            // txt_numero_conta
            // 
            this.txt_numero_conta.Location = new System.Drawing.Point(213, 89);
            this.txt_numero_conta.Name = "txt_numero_conta";
            this.txt_numero_conta.Size = new System.Drawing.Size(219, 20);
            this.txt_numero_conta.TabIndex = 9;
            // 
            // txt_saldoatual
            // 
            this.txt_saldoatual.Location = new System.Drawing.Point(213, 125);
            this.txt_saldoatual.Name = "txt_saldoatual";
            this.txt_saldoatual.Size = new System.Drawing.Size(219, 20);
            this.txt_saldoatual.TabIndex = 10;
            this.txt_saldoatual.Text = "0";
            // 
            // TXT_VALOR
            // 
            this.TXT_VALOR.Location = new System.Drawing.Point(213, 252);
            this.TXT_VALOR.Name = "TXT_VALOR";
            this.TXT_VALOR.Size = new System.Drawing.Size(219, 20);
            this.TXT_VALOR.TabIndex = 11;
            this.TXT_VALOR.Text = "0";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(82, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(283, 24);
            this.label1.TabIndex = 12;
            this.label1.Text = "BANCO DO PEDRO PASSOS";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // rdb_sacar
            // 
            this.rdb_sacar.AutoSize = true;
            this.rdb_sacar.Location = new System.Drawing.Point(213, 200);
            this.rdb_sacar.Name = "rdb_sacar";
            this.rdb_sacar.Size = new System.Drawing.Size(61, 17);
            this.rdb_sacar.TabIndex = 13;
            this.rdb_sacar.TabStop = true;
            this.rdb_sacar.Text = "SACAR";
            this.rdb_sacar.UseVisualStyleBackColor = true;
            // 
            // rdb_depositar
            // 
            this.rdb_depositar.AutoSize = true;
            this.rdb_depositar.Location = new System.Drawing.Point(345, 200);
            this.rdb_depositar.Name = "rdb_depositar";
            this.rdb_depositar.Size = new System.Drawing.Size(87, 17);
            this.rdb_depositar.TabIndex = 14;
            this.rdb_depositar.TabStop = true;
            this.rdb_depositar.Text = "DEPOSITAR";
            this.rdb_depositar.UseVisualStyleBackColor = true;
            // 
            // BTN_EXECUTAR
            // 
            this.BTN_EXECUTAR.Location = new System.Drawing.Point(37, 323);
            this.BTN_EXECUTAR.Name = "BTN_EXECUTAR";
            this.BTN_EXECUTAR.Size = new System.Drawing.Size(170, 23);
            this.BTN_EXECUTAR.TabIndex = 15;
            this.BTN_EXECUTAR.Text = "EXECUTAR";
            this.BTN_EXECUTAR.UseVisualStyleBackColor = true;
            this.BTN_EXECUTAR.Click += new System.EventHandler(this.BTN_EXECUTAR_Click);
            // 
            // BTN_NOVA_CONTA
            // 
            this.BTN_NOVA_CONTA.Location = new System.Drawing.Point(238, 323);
            this.BTN_NOVA_CONTA.Name = "BTN_NOVA_CONTA";
            this.BTN_NOVA_CONTA.Size = new System.Drawing.Size(194, 23);
            this.BTN_NOVA_CONTA.TabIndex = 16;
            this.BTN_NOVA_CONTA.Text = "NOVA CONTA";
            this.BTN_NOVA_CONTA.UseVisualStyleBackColor = true;
            this.BTN_NOVA_CONTA.Click += new System.EventHandler(this.BTN_NOVA_CONTA_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(473, 427);
            this.Controls.Add(this.BTN_NOVA_CONTA);
            this.Controls.Add(this.BTN_EXECUTAR);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.rdb_sacar);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.rdb_depositar);
            this.Controls.Add(this.TXT_VALOR);
            this.Controls.Add(this.txt_saldoatual);
            this.Controls.Add(this.txt_numero_conta);
            this.Controls.Add(this.txt_titular);
            this.Controls.Add(this.lbl_valor);
            this.Controls.Add(this.lbl_numeroconta);
            this.Controls.Add(this.lbl_saldo);
            this.Controls.Add(this.lbl_titular);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_titular;
        private System.Windows.Forms.Label lbl_saldo;
        private System.Windows.Forms.Label lbl_numeroconta;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label lbl_valor;
        private System.Windows.Forms.TextBox txt_titular;
        private System.Windows.Forms.TextBox txt_numero_conta;
        private System.Windows.Forms.TextBox txt_saldoatual;
        private System.Windows.Forms.TextBox TXT_VALOR;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.RadioButton rdb_sacar;
        private System.Windows.Forms.RadioButton rdb_depositar;
        private System.Windows.Forms.Button BTN_EXECUTAR;
        private System.Windows.Forms.Button BTN_NOVA_CONTA;
    }
}

