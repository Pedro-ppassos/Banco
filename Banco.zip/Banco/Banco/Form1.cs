﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Banco
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void BTN_EXECUTAR_Click(object sender, EventArgs e)
        {

            //VARIAVEIS 


            txt_numero_conta.Enabled = false;
            txt_titular.Enabled = false;
            txt_saldoatual.Enabled = false;

            
            string nome_titular = txt_titular.Text;
            double saldo = double.Parse(txt_saldoatual.Text);
            double valor = double.Parse(TXT_VALOR.Text);
            string numero_conta = txt_numero_conta.Text;

            if (rdb_depositar.Checked)     
            {
                saldo = saldo + valor;
            }
            else if (rdb_sacar.Checked)
            {
                saldo = saldo - valor;
            }
            else
            {
                MessageBox.Show("Selecione uma Operação.");
            }

            txt_saldoatual.Text = saldo.ToString();


        }

        private void BTN_NOVA_CONTA_Click(object sender, EventArgs e)
        {


            txt_numero_conta.Enabled = true;
            txt_titular.Enabled = true;
            txt_saldoatual.Enabled = true;
            txt_numero_conta.Clear();
            txt_saldoatual.Text = "0";
            rdb_sacar.Checked = false;
            rdb_depositar.Checked = false;
            TXT_VALOR.Text = "0";








        }
    }
}
